# PerformanceSuite-Windows  
by Luzifer-Black

Ein automatisches Windows-Optimierungs-System  
für Fortnite, SWTOR und alle neuen Spiele.

## Installation:
PowerShell als Administrator öffnen und folgendes ausführen:

```
powershell -ExecutionPolicy Bypass -Command "irm 'https://raw.githubusercontent.com/Luzifer-Black/PerformanceSuite-Windows/main/install.ps1' | iex"
```

## Funktionen:
- Automatische Spiele-Erkennung
- Fortnite FPS-Booster
- SWTOR Optimizer
- Sichere GPU Overclock-Profile (MSI Afterburner)
- Ryzen RAM Boost
- Netzwerk-Latenz Optimierung
- RAM Cache Reinigung
- Energiesparplan Umschaltung
- Temperaturüberwachung (CPU & GPU)
- Automatische Updates
- Auto-Start beim Login
